USE school_db;

DROP TABLE students;

Drop table teacher;

SHOW TABLES LIKE 'students';


